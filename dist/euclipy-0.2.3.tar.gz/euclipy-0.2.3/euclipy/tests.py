from construct import *

print('Test')