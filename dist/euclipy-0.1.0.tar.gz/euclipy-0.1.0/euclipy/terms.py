undefined = "undefined"
alpha = (u"\u03b1")
beta = (u"\u03b2")
phi = (u"\u03c6")