# Euclipy
## A library used to create, model, and solve figures in Euclidean Geometry.